<?php
require_once __DIR__ . '/inc/menu.class.php';
function plugin_ticketfinder_install(): bool { return true; }
function plugin_ticketfinder_uninstall(): bool { return true; }
