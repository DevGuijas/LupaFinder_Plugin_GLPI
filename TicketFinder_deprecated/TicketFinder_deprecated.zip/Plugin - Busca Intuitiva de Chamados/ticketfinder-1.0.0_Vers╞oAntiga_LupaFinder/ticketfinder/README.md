# Busca Intuitiva de Chamados

Plugin para GLPI 11.0.1 a 11.0.x. Oferece uma tela simples para localizar chamados e encaminha a consulta ao mecanismo nativo do GLPI, preservando perfis, entidades e visibilidade.

## O que oferece

- Campo único para número, título e descrição.
- Atalhos para chamados em atendimento, aguardando, resolvidos e solicitados pelo usuário atual.
- Filtros para status, prioridade, tipo, categoria, solicitante, técnico e período.
- Resultado na listagem padrão do GLPI, com exportação e ações em massa disponíveis.

## Instalação

1. Copie a pasta `ticketfinder` para `<raiz-do-glpi>/plugins/`.
2. Em **Configuração > Plugins**, instale e habilite **Busca Intuitiva de Chamados**.
3. Acesse **Assistência > Busca rápida de chamados**.

O plugin não cria tabelas e não altera arquivos do núcleo do GLPI.
