<?php
/** @var array $CFG_GLPI */
require_once dirname(__DIR__, 3) . '/inc/includes.php';
Session::checkLoginUser();
Session::checkRight('ticket', READ);

function ticketfinder_add_criterion(array &$criteria, int $field, string $searchtype, string|int $value): void {
 if ($value === '' || $value === 0 || $value === '0') return;
 $criteria[] = ['link'=>'AND','field'=>$field,'searchtype'=>$searchtype,'value'=>$value];
}
if (isset($_GET['apply'])) {
 $criteria=[]; $term=trim((string)($_GET['term'] ?? ''));
 if ($term !== '') {
  if (ctype_digit($term)) ticketfinder_add_criterion($criteria,2,'equals',$term);
  else { ticketfinder_add_criterion($criteria,1,'contains',$term); $criteria[]=['link'=>'OR','field'=>21,'searchtype'=>'contains','value'=>$term]; }
 }
 ticketfinder_add_criterion($criteria,12,'equals',(string)($_GET['status']??''));
 ticketfinder_add_criterion($criteria,3,'equals',(string)($_GET['priority']??''));
 ticketfinder_add_criterion($criteria,14,'equals',(string)($_GET['type']??''));
 ticketfinder_add_criterion($criteria,7,'equals',(string)($_GET['category']??''));
 ticketfinder_add_criterion($criteria,4,'equals',(string)($_GET['requester']??''));
 ticketfinder_add_criterion($criteria,5,'equals',(string)($_GET['technician']??''));
 ticketfinder_add_criterion($criteria,15,'morethan',(string)($_GET['opened_from']??''));
 ticketfinder_add_criterion($criteria,15,'lessthan',(string)($_GET['opened_to']??''));
 Html::redirect($CFG_GLPI['root_doc'].'/front/ticket.php?'.http_build_query(['criteria'=>$criteria,'sort'=>19,'order'=>'DESC']));
}
$page_url=$CFG_GLPI['root_doc'].'/plugins/ticketfinder/front/search.php';
Html::header(__('Busca rápida de chamados','ticketfinder'),'','helpdesk','ticket');
?>
<style>
.ticketfinder-shell{max-width:1120px;margin:1.5rem auto 3rem}.ticketfinder-hero{background:linear-gradient(125deg,#0f5b78,#16769c);color:#fff;border-radius:14px;padding:2rem;box-shadow:0 12px 26px rgba(15,91,120,.18)}.ticketfinder-hero h1{margin:0 0 .4rem;font-size:1.55rem;color:#fff}.ticketfinder-hero p{margin:0;opacity:.92}.ticketfinder-card{margin-top:-1rem;position:relative;border-radius:14px}.ticketfinder-field label{display:block;font-weight:600;margin:0 0 .35rem}.ticketfinder-term{font-size:1.1rem;min-height:48px}.ticketfinder-quick button{margin:.25rem .35rem .25rem 0}.ticketfinder-help{color:var(--tblr-secondary,#667);font-size:.9rem}@media(max-width:767px){.ticketfinder-shell{margin-top:.75rem}.ticketfinder-hero{border-radius:0}}
</style>
<main class="ticketfinder-shell px-3">
 <section class="ticketfinder-hero"><h1><i class="ti ti-search me-2" aria-hidden="true"></i><?=htmlescape(__('Encontre um chamado sem montar filtros complexos','ticketfinder'))?></h1><p><?=htmlescape(__('Digite um número, uma palavra do título ou da descrição. Depois, refine apenas o que for necessário.','ticketfinder'))?></p></section>
 <section class="card ticketfinder-card shadow-sm"><div class="card-body p-4"><form method="get" action="<?=htmlescape($page_url)?>" id="ticketfinder-search-form"><input type="hidden" name="apply" value="1">
 <div class="ticketfinder-field mb-3"><label for="ticketfinder-term"><?=htmlescape(__('O que você procura?','ticketfinder'))?></label><input class="form-control ticketfinder-term" id="ticketfinder-term" name="term" type="search" autofocus autocomplete="off" placeholder="<?=htmlescape(__('Ex.: 12345, impressora, acesso ao sistema','ticketfinder'))?>"><div class="ticketfinder-help mt-1"><?=htmlescape(__('Somente números pesquisam pelo número do chamado; textos pesquisam no título e na descrição.','ticketfinder'))?></div></div>
 <div class="ticketfinder-quick mb-4"><span class="fw-semibold me-2"><?=htmlescape(__('Atalhos:','ticketfinder'))?></span><button class="btn btn-outline-primary btn-sm" type="button" data-status="2"><?=htmlescape(__('Em atendimento','ticketfinder'))?></button><button class="btn btn-outline-primary btn-sm" type="button" data-status="4"><?=htmlescape(__('Aguardando','ticketfinder'))?></button><button class="btn btn-outline-primary btn-sm" type="button" data-status="5"><?=htmlescape(__('Resolvidos','ticketfinder'))?></button><button class="btn btn-outline-primary btn-sm" type="button" data-mine="<?= (int) Session::getLoginUserID() ?>"><?=htmlescape(__('Solicitados por mim','ticketfinder'))?></button></div>
 <details class="mb-4"><summary class="fw-semibold cursor-pointer"><?=htmlescape(__('Mais filtros','ticketfinder'))?></summary><div class="row g-3 mt-1">
 <div class="col-md-4 ticketfinder-field"><label for="ticketfinder-status"><?=htmlescape(__('Status','ticketfinder'))?></label><select class="form-select" id="ticketfinder-status" name="status"><option value=""><?=htmlescape(__('Todos','ticketfinder'))?></option><option value="1"><?=htmlescape(__('Novo','ticketfinder'))?></option><option value="2"><?=htmlescape(__('Em atendimento','ticketfinder'))?></option><option value="3"><?=htmlescape(__('Planejado','ticketfinder'))?></option><option value="4"><?=htmlescape(__('Aguardando','ticketfinder'))?></option><option value="5"><?=htmlescape(__('Solucionado','ticketfinder'))?></option><option value="6"><?=htmlescape(__('Fechado','ticketfinder'))?></option></select></div>
 <div class="col-md-4 ticketfinder-field"><label for="ticketfinder-priority"><?=htmlescape(__('Prioridade','ticketfinder'))?></label><select class="form-select" id="ticketfinder-priority" name="priority"><option value=""><?=htmlescape(__('Todas','ticketfinder'))?></option><option value="1"><?=htmlescape(__('Muito baixa','ticketfinder'))?></option><option value="2"><?=htmlescape(__('Baixa','ticketfinder'))?></option><option value="3"><?=htmlescape(__('Média','ticketfinder'))?></option><option value="4"><?=htmlescape(__('Alta','ticketfinder'))?></option><option value="5"><?=htmlescape(__('Muito alta','ticketfinder'))?></option></select></div>
 <div class="col-md-4 ticketfinder-field"><label for="ticketfinder-type"><?=htmlescape(__('Tipo','ticketfinder'))?></label><select class="form-select" id="ticketfinder-type" name="type"><option value=""><?=htmlescape(__('Todos','ticketfinder'))?></option><option value="1"><?=htmlescape(__('Incidente','ticketfinder'))?></option><option value="2"><?=htmlescape(__('Requisição','ticketfinder'))?></option></select></div>
 <div class="col-md-6 ticketfinder-field"><label><?=htmlescape(__('Categoria','ticketfinder'))?></label><?php ITILCategory::dropdown(['name'=>'category','value'=>0,'display_emptychoice'=>true]); ?></div>
 <div class="col-md-3 ticketfinder-field"><label><?=htmlescape(__('Solicitante','ticketfinder'))?></label><?php User::dropdown(['name'=>'requester','value'=>0,'right'=>'all','display_emptychoice'=>true]); ?></div>
 <div class="col-md-3 ticketfinder-field"><label><?=htmlescape(__('Técnico','ticketfinder'))?></label><?php User::dropdown(['name'=>'technician','value'=>0,'right'=>'own_ticket','display_emptychoice'=>true]); ?></div>
 <div class="col-md-3 ticketfinder-field"><label for="ticketfinder-opened-from"><?=htmlescape(__('Aberto a partir de','ticketfinder'))?></label><input class="form-control" id="ticketfinder-opened-from" name="opened_from" type="date"></div>
 <div class="col-md-3 ticketfinder-field"><label for="ticketfinder-opened-to"><?=htmlescape(__('Aberto até','ticketfinder'))?></label><input class="form-control" id="ticketfinder-opened-to" name="opened_to" type="date"></div>
 </div></details>
 <div class="d-flex gap-2 justify-content-end"><a class="btn btn-link" href="<?=htmlescape($page_url)?>"><?=htmlescape(__('Limpar','ticketfinder'))?></a><button class="btn btn-primary px-4" type="submit"><i class="ti ti-search me-1" aria-hidden="true"></i><?=htmlescape(__('Buscar chamados','ticketfinder'))?></button></div>
 </form></div></section>
</main>
<script>
document.querySelectorAll('[data-status],[data-mine]').forEach((button)=>button.addEventListener('click',()=>{const status=document.getElementById('ticketfinder-status'),requester=document.querySelector('[name="requester"]');if(button.dataset.status)status.value=button.dataset.status;if(button.dataset.mine&&requester)requester.value=button.dataset.mine;document.getElementById('ticketfinder-search-form').requestSubmit();}));
</script>
<?php Html::footer(); ?>
