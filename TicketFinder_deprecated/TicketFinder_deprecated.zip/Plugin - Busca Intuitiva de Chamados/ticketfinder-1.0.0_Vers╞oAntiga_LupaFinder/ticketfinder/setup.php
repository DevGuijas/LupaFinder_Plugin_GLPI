<?php
define('PLUGIN_TICKETFINDER_VERSION', '1.0.0');
function plugin_init_ticketfinder(): void {
 global $PLUGIN_HOOKS;
 $PLUGIN_HOOKS['csrf_compliant']['ticketfinder'] = true;
 $PLUGIN_HOOKS['menu_toadd']['ticketfinder'] = ['helpdesk' => 'PluginTicketfinderMenu'];
}
function plugin_version_ticketfinder(): array {
 return ['name'=>'Busca Intuitiva de Chamados','version'=>PLUGIN_TICKETFINDER_VERSION,'author'=>'SCRB','license'=>'GPL-3.0-or-later','requirements'=>['glpi'=>['min'=>'11.0.1','max'=>'11.0.99']]];
}
function plugin_ticketfinder_check_prerequisites(): bool { return version_compare(GLPI_VERSION,'11.0.1','>=') && version_compare(GLPI_VERSION,'11.1.0','<'); }
function plugin_ticketfinder_check_config($verbose = false): bool { return true; }
