<?php
class PluginTicketfinderMenu {
 public static function getTypeName($nb = 0): string { return __('Busca rápida de chamados', 'ticketfinder'); }
 public static function getMenuContent(): array {
  global $CFG_GLPI;
  $url = $CFG_GLPI['root_doc'] . '/plugins/ticketfinder/front/search.php';
  return ['title'=>self::getTypeName(),'page'=>$url,'icon'=>'ti ti-search','options'=>[],'links'=>['search'=>$url]];
 }
}
